<?php
$nombre= $_POST['nombre'];
$documento= $_POST['documento'];
$edad= $_POST['edad'];


if ($edad >= 18) {
    
    echo ("Señor ".$nombre." con numero de documento: ".$documento." has sido registrado ya que su edad es ".$edad);
}

else{
    echo ("Error");
}

