<?php
$descripcion= $_POST['descripcion'];
$venta= $_POST['venta'];



if ($venta > 0) {
    
    echo ("La descripcion de la venta ".$descripcion." y el valor total de la venta : ".$venta);
}

else{
    echo ("Error");
}