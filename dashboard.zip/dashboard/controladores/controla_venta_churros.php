<?php
$cantida_churos=$_POST["cantidad"];
$churros = 1800;
$total=$cantida_churos*$churros;

echo $total."valor";
?>