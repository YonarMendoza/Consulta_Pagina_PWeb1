<?php
$nombre_persona = $_POST["nombre"];
$documento = $_POST["documento"];
$celular = $_POST["celular"];
$fecha_nacimiento= $_POST["fecha_de_nacimiento"];

 echo "el celular es:".$celular;
 echo "<br>la fecha es:".$fecha_de_nacimiento;
 echo "<br>el numero de cumento"
?>