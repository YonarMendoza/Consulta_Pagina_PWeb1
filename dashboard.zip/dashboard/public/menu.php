<ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2 active" aria-current="page" href="electivas.php">
                <svg class="bi"><use xlink:href="#house-fill"/></svg>
                electivas 
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="#prematricula.php">
                <svg class="bi"><use xlink:href="#file-earmark"/></svg>
                prematricula
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="financiera.php">
                <svg class="bi"><use xlink:href="#cart"/></svg>
                matricula financiera
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="horarios.php">
                <svg class="bi"><use xlink:href="#people"/></svg>
                horarios
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="notas.php">
                <svg class="bi"><use xlink:href="#graph-up"/></svg>
                notas
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="#">
                <svg class="bi"><use xlink:href="#puzzle"/></svg>
                Integrations
              </a>
            </li>
          </ul>

      